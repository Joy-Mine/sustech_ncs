A python impletation of NCS-C.

K. Tang, P. Yang and X. Yao, "Negatively Correlated Search," in IEEE Journal on Selected Areas in Communications, vol. 34, no. 3, pp. 542-550, March 2016, doi: 10.1109/JSAC.2016.2525458.