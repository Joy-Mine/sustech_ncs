from .NCS_mul_pack import NCS
from .NCS_noMul_pack import NCS as NCS_noMul
from .NCS_mul_asym import NCS as NCS_asym

__version__ = "0.0.4"

name = "sustech_ncs"