from .NCS_mul_pack import NCS
from .NCS_noMul_pack import NCS as NCS_

__version__ = "0.0.3"

name = "sustech_ncs"